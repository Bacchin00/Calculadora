
package com.example.calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.btn0), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Toast.makeText(this, "Boa Noiotye", Toast.LENGTH_LONG).show();
    }

    public void numero(View v){

        Button botao = findViewById(v.getId());

        TextView visor = (TextView) findViewById(R.id.txtVisor);

        visor.setText( visor.getText().toString() + botao.getText().toString() );

    }

    public void apagar(View v){

        Button apagar = findViewById(R.id.btnApagar);

        TextView visor = (TextView) findViewById(R.id.txtVisor);

        visor.setText("");
    }

    public void  calcular(){

        TextView visor = (TextView) findViewById(R.id.txtVisor);

    }
}